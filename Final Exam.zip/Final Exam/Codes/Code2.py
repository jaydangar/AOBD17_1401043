#	Import for Parsing Operations
from __future__ import print_function
import json
import re
from collections import Counter
import matplotlib.pyplot as plt

#	For this particular Problem to solve clustering is needed in order to cluster data into a group so that it is easy to classify common characteristic out and compare it with user's choice. The more choice matches with clustered data the more possibility of the success of user's career should be high.

#	In Programming i find out difficulty in order to cluster string data which includes other language also. so, to tackle the problem i took a simple approach that i myself do clustering and then other tasks i will left for computer.

#	After Clustering we can seprate out which the technology is used in which development

var = raw_input("Enter Skills to develop in career path : ")
  
Jrt = ["corejava","javaavanado","ejb","java","javabsico","javaintermedirio","programadorjava"]	
#	Java Related Technology

Jdt  = ["eclipse","netbeans","visual studio"]
#  	Java Development Tools

Crt = ["c++","qt","boostc++","stlc++","cbsico","cintermedirio","cavanado"]
#	C++ Related Technology

Cdt = ["eclipse","netbeans","devc++","codeblocks","visualstudio"]	
#	C++ Development Tools

Wd =["html","css","javascript","nodejs","angularjs","bootstrap","php","apache","webservices","eclipse","dreamviewer","netbeans","asp.net","visualstudio",
"htmlbsico","htmlintermedirio","htmlavanado","cssbsico","cssintermedirio","cssavanado","phpbsico","phpintermedirio","phpavanado","javascriptbsico","javascriptintermedirio","javascriptavanado"]
#	Web Development

OS = ["linux","windows","drivers"]
#	Operating Systems

ET = ["git","firebug","vba","visualbasic","googledrive","onedrive","msoffice","msexcel","mspowerpoint"]
#	Extratools

DBMS = ["mysql","mongodb","hibernate","sql","microsoftsqlserver","oracle","microsoftaccess","sqlserver","postgresql"]
#	Database Management Systems

WUD = ["html","css","bootstrap","qt","dreamviewer","ireport","jsf","ejb"]
#	Web UI/UX Development

WinUD = ["qt","eclipse","netbeans","coreldraw","xml"]
#	Windows UI/UX Development

AAD = ["corejava","advancejava","webservices","jsonparsing"]
#	Android App Development

GD = ["c#","unity","c#bsico","c#intermedirio","c#avanado"]
#	Game Development

AI = ["imageprocessing","matlab","python","neuralnetwork","fuzzylogic","opencv","pythonbsico","pythonintermedirio","pythonavanado"]
#	Artificial Intelligence

IAD = ["objective-c","swift","objective-cbsico","objective-cintermedirio","objective-cavanado"]
#	IOS App Development

IADT = ["objective-c","xcode"]
#	IOS App development tools

List = []

#	JavaDeveloper Data
javadata = json.loads(open("/media/jay/Jay/ICT Sem 6/AOBD/Final Exam/Data/Java Developer.txt","r").read())

#	Iteration over Length of JsonArray        
for i in javadata:
    MakeList = i['Skills']	

    #	Creating Name of Coma Separated List and converted all the strings into lower case
    my_list = json.dumps(MakeList).decode('unicode-escape').encode('ascii','ignore').lower()
    
    #removing first and last double quotes from strings
    my_list = my_list[1:-1]
    	
    #	Taking out string separated by , and /  
    array = re.split('; | / ',my_list)
        
    array = list(array)
    
    #	Taking out [] and first and last ' from list, also removing space from the elements    
    array = str(array).strip('[]')
    array = str(array[1:-1])
    array = ''.join(str(array).split(" "))    
    
    #	Separating out elements by comma and creating a list
    array = array.split(",")
    
   #	Printing Individual String from a list    
    for w in array:
    #	Removing the content from Two Rounded Braces to make comparison easy
    	temp = re.sub(r'\([^)]*\)', '',w).lower()
    	List.append(temp)

List  = List[:25]
# Taking First Candidate's Profile	

print ('Career Development Suggestion is ')
print (Jrt)
print ('Useful Tools for Java Development is ')
print (Jdt)
'''
#	Calculating Difference between User's Skills and Java Programming Skills
print ('Difference between Users Skills and Java Programming Skills : ' , len(list(set(Jrt) - set(List))))

#	Calculating Difference between User's Skills and Java Development Tools Skills
print ('Difference between Users Skills and Java Development Tools Skills  : ' , len(list(set(Jdt) - set(List))))

#	Calculating Difference between Users Skills and c Programming Skills 
print ('Difference between Users Skills and c Programming Skills : ' , len(list(set(Crt) - set(List))))

#	Calculating Difference between Users Skills and c Development Tools Skills
print ('Difference between Users Skills  and c Development Tools Skills  : ' ,len(list(set(Cdt) - set(List))))

#	Calculating Difference between User's Skills and Web Development Skills
print ('Difference between Users Skills and Web Development Skills : ' , len(list(set(Wd) - set(List))))

#	Calculating Difference between User's Skills and Operating System Skills
print ('Difference between Users Skills and Operating System Skills : ' , len(list(set(OS) - set(List))))

#	Calculating Difference between User's Skills and Extratools Skills
print ('Difference between Users Skills and Extratools Skills : ' , len(list(set(ET) - set(List))))

#	Calculating Difference between User's Skills and Database Skills
print ('Difference between Users Skills and Database Skills : ' , len(list(set(DBMS) - set(List))))

#	Calculating Difference between User's Skills and Web User Design Skills
print ('Difference between Users Skills and Web User Design Skills : ' , len(list(set(WUD) - set(List))))

#	Calculating Difference between User's Skills and Windows User Design Skills
print ('Difference between Users Skills and Windows User Design Skills : ' , len(list(set(WinUD) - set(List))))

#	Calculating Difference between User's Skills and Android App Development Skills
print ('Difference between Users Skills and Android App Development : ' , len(list(set(AAD) - set(List))))

#	Calculating Difference between User's Skills and Game Development Skills
print ('Difference between Users Skills and Game Development Skills : ' , len(list(set(GD) - set(List))))

#	Calculating Difference between User's Skills and Artificial Intelligence Skills
print ('Difference between Users Skills and Artificial Intelligence Skills : ' , len(list(set(AI) - set(List))))

#	Calculating Difference between User's Skills and IOS App Development Skills
print ('Difference between Users Skills and IOS App Development Skills : ', len(list(set(IAD) - set(List))))

#	Calculating Difference between User's Skills and IOS APp development Tools Skills
print ('Difference between Users Skills and IOS APp development Tools Skills : ' , len(list(set(IADT) - set(List))))
'''


